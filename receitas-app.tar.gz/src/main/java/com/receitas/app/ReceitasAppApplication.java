package com.receitas.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceitasAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReceitasAppApplication.class, args);
    }
}
